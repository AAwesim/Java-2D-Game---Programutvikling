/*package sample.Entity;

import javafx.scene.layout.Pane;

import static javafx.scene.paint.Color.BLUE;

public class EnemyCircleSmall extends EnemyCircle {


    private double CPosX;
    private double CPosY;

    public EnemyCircleSmall(double centerX, double centerY, double radius, Pane p) {
        super(centerX, centerY, radius, p);
        this.setCPosX(centerX);
        this.setCPosY(centerY);
        this.setFill(BLUE);
        }

}
*/